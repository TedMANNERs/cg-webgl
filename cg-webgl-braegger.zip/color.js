export const RED = { r:1, g:0, b:0, a:1 };
export const GREEN = { r:0, g:1, b:0, a:1 };
export const BLUE = { r:0, g:0, b:1, a:1 };
export const YELLOW = { r:1, g:1, b:0, a:1 };

export const BLACK = { r:0, g:0, b:0, a:1 };
export const WHITE = { r:1, g:1, b:1, a:1 };